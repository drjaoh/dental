import React from 'react';
import Icon from '../../../components/AppIcon';

const FinancialMetricsCard = ({ title, value, change, changeType, icon, color = "primary" }) => {
  const getColorClasses = () => {
    switch (color) {
      case 'success':
        return 'bg-success/10 border-success/20 text-success';
      case 'warning':
        return 'bg-warning/10 border-warning/20 text-warning';
      case 'error':
        return 'bg-error/10 border-error/20 text-error';
      default:
        return 'bg-primary/10 border-primary/20 text-primary';
    }
  };

  const getChangeColor = () => {
    return changeType === 'positive' ? 'text-success' : 'text-error';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 clinical-shadow transition-clinical hover:clinical-shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses()}`}>
          <Icon name={icon} size={24} />
        </div>
        {change && (
          <div className={`flex items-center space-x-1 ${getChangeColor()}`}>
            <Icon 
              name={changeType === 'positive' ? 'TrendingUp' : 'TrendingDown'} 
              size={16} 
            />
            <span className="text-sm font-medium">{change}</span>
          </div>
        )}
      </div>
      <div>
        <h3 className="text-sm font-medium text-muted-foreground mb-1">{title}</h3>
        <p className="text-2xl font-bold text-foreground">{value}</p>
      </div>
    </div>
  );
};

export default FinancialMetricsCard;